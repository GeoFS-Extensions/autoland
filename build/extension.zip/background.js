"use strict";
// TODO: cache options from chrome.storage, respond to chrome.storage.onChanged
