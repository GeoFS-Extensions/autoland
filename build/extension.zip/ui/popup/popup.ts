interface popupState {
	ap: boolean
	fmc: boolean
}

var ap: boolean = false
var fmc: boolean = false
var options: popupState = readStateFromMemory()

function writeStateToMemory(state: popupState): popupState {
	chrome.storage.sync.set({options: state}, () => {})
	return state
}

function readStateFromMemory(): popupState {
	var data: popupState
	chrome.storage.sync.get("options", (items) => {
		if (items.options) {
			data = items.options
		} else {
			data = {
				ap: false,
				fmc: false
			}
		}
	})

	return data
}

function getCurrentPopupState(): popupState {
	return {
		ap: ap,
		fmc: fmc
	}
}

function update(): void {
	// TODO: update
}