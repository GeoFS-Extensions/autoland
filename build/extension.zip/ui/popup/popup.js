"use strict";
var ap = false;
var fmc = false;
var options = readStateFromMemory();
function writeStateToMemory(state) {
    chrome.storage.sync.set({ options: state }, function () { });
    return state;
}
function readStateFromMemory() {
    var data;
    chrome.storage.sync.get("options", function (items) {
        if (items.options) {
            data = items.options;
        }
        else {
            data = {
                ap: false,
                fmc: false
            };
        }
    });
    return data;
}
function getCurrentPopupState() {
    return {
        ap: ap,
        fmc: fmc
    };
}
function update() {
    // TODO: update
}
