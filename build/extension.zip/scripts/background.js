"use strict";
var options = getCurrentOptions();
function getCurrentOptions() {
    var data;
    chrome.storage.sync.get("options", function (items) {
        if (items.options) {
            data = items.options;
        }
        else {
            data = {
                ap: false,
                fmc: false
            };
        }
    });
    return data;
}
// update cache when storage changes
chrome.storage.onChanged.addListener(function () {
    options = getCurrentOptions();
});
