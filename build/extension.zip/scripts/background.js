"use strict";
var options = getCurrentOptions();
function getCurrentOptions() {
    var data;
    chrome.storage.sync.get("options", function (items) {
        if (items.options) {
            data = items.options;
        }
        else {
            data = {
                ap: false,
                fmc: false
            };
        }
    });
    return data;
}
// update cache when storage changes
chrome.storage.onChanged.addListener(function () {
    options = getCurrentOptions();
});
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg.name != "geoContentScript") {
        return;
    }
    if (msg.needsData) {
        sendResponse({ options: options });
    }
});
